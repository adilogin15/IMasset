import React from 'react';
import tech from './tech.jpg';
import './Home.css';


const Home=()=>{
    return(
        <div className="body1">
            <img className="backImage" src={tech}  alt=""/>          
        </div>
    )
}


export default Home;