import React from 'react';

const Card=()=>{
    return(
        <div className="mainContainer">
            <div className="cardsContainer">
                <div className="cards">

                </div>
                <div className="cards">

                </div>
                <div className="cards">

                </div>
            </div>
        </div>
    )
}

export default Card;