import React from 'react';
import Navigation from './Navigation';
import Home from './Home';

const SolutionWorkshops=()=>{
    return (
        <div>
          <Navigation />
          <Home/>
        </div>
      );
}

export default SolutionWorkshops;