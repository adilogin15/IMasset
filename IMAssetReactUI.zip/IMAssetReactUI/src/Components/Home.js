import React from 'react';
import tech from './tech.jpg';

const Home=()=>{
    return(
        <div className="homewrapper">
            <img className="backImage" src={tech}  alt="hompagebackground"/>          
        </div>
    )
}

export default Home;