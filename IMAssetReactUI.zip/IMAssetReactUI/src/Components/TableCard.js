import React from 'react';

const TableCard=()=>{
    return(
        <div className="maintcContainer">
            <div className="cardsContainer">
                <div className="tablecards">

                </div>
                <div className="tablecards">

                </div>
            </div>
        </div>
    )
}

export default TableCard;